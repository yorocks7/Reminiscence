package com.ahel.reminiscence;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class sixth extends Activity {


    Intent intent;

    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.popup_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1:
                intent=new Intent(sixth.this,OpeningActivity.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                intent=new Intent(sixth.this,first.class);
                startActivity(intent);
                return true;
            case R.id.item3:
                intent=new Intent(sixth.this,second.class);
                startActivity(intent);
                return true;
            case R.id.item4:
                intent=new Intent(sixth.this,third.class);
                startActivity(intent);
                return true;
            case R.id.item5:
                Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.reminiscencemet80.com/speakers"));
                startActivity(browserIntent);
                return true;
            case R.id.item6:
                intent=new Intent(sixth.this,fifth.class);
                startActivity(intent);
                return true;
            case R.id.item7:
                intent=new Intent(sixth.this, sixth.class);
                startActivity(intent);
                return true;
            case R.id.item8:
                intent=new Intent(sixth.this, team.class);
                startActivity(intent);
            default:
                return false;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sixth);
    }
}
