package com.ahel.reminiscence;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

public class third extends Activity {
    Intent intent;
    @Override

    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.popup_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1:
                intent=new Intent(third.this,OpeningActivity.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                intent=new Intent(third.this,first.class);
                startActivity(intent);
                return true;
            case R.id.item3:
                intent=new Intent(third.this,second.class);
                startActivity(intent);
                return true;
            case R.id.item4:
                intent=new Intent(third.this,third.class);
                startActivity(intent);
                return true;
            case R.id.item5:
                Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.reminiscencemet80.com/speakers"));
                startActivity(browserIntent);
                return true;
            case R.id.item6:
                intent=new Intent(third.this,fifth.class);
                startActivity(intent);
                return true;
            default:
                return false;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        ImageButton back=(ImageButton) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent=new Intent(third.this,OpeningActivity.class);
                startActivity(browserIntent);
            }
        });
    }
}
