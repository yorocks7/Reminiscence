
package com.ahel.reminiscence;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.ahel.reminiscence.R;

public class fifth extends Activity {
    int i;
    Intent intent;

    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.popup_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.item1:
                intent=new Intent(fifth.this,OpeningActivity.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                intent=new Intent(fifth.this,first.class);
                startActivity(intent);
                return true;
            case R.id.item3:
                intent=new Intent(fifth.this,second.class);
                startActivity(intent);
                return true;
            case R.id.item4:
                intent=new Intent(fifth.this,third.class);
                startActivity(intent);
                return true;
            case R.id.item5:
                Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.reminiscencemet80.com/speakers"));
                startActivity(browserIntent);
                return true;
            case R.id.item6:
                intent=new Intent(fifth.this,fifth.class);
                startActivity(intent);
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);

        ImageButton call=(ImageButton)findViewById(R.id.button1);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i=0;
                initiateCall();
            }
        });

        ImageButton call1=(ImageButton)findViewById(R.id.button2);
        call1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i=1;
                initiateCall();
            }
        });


    }

    public void initiateCall(){
        if(checkifalready()){
            makethecall();
        }else{
            requestCallPermission();
        }
    }

    private boolean checkifalready(){
        int result= ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
        if(result== PackageManager.PERMISSION_GRANTED){
            return true;
        }
        else{
            return false;
        }
    }

    private void requestCallPermission(){
        ActivityCompat.requestPermissions(fifth.this,new String[]{Manifest.permission.CALL_PHONE},1);
    }

    private void onRequestCallPermission(int requestCode,String permissions[],int grantResults[]){
        switch (requestCode){
            case 1:if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                makethecall();
            }
        }
    }

    private void makethecall(){
        Intent intent=new Intent(Intent.ACTION_CALL);
        if(i==0){
            intent.setData(Uri.parse("tel:8017305080"));
        }
        else{
            intent.setData(Uri.parse("tel:8777030028"));
        }
        startActivity(intent);
    }

    public void mail(View view){
        Intent intent=new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,new String[]{"contact@reminiscencemet80.com"});
        intent.putExtra(Intent.EXTRA_SUBJECT,"QUERY REGARDING REMINISCENCE'20");
        if ((intent.resolveActivity(getPackageManager())!=null)){
            startActivity(intent);
        }
    }

    public void site(View view){
        Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.reminiscencemet80.com/"));
        startActivity(browserIntent);
    }

    public void back(View view){
        Intent intent=new Intent(fifth.this,OpeningActivity.class);
        startActivity(intent);
    }
}